--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2 (Ubuntu 13.2-1)
-- Dumped by pg_dump version 13.2 (Ubuntu 13.2-1)

-- Started on 2021-05-17 21:30:09 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 3714 (class 1259 OID 241034)
-- Name: wordcounts_w; Type: TABLE; Schema: public; Owner: hippa_wr
--

CREATE TABLE public.wordcounts_w (
    entry_name character varying(64),
    total_count integer DEFAULT 0,
    gr_count integer DEFAULT 0,
    lt_count integer DEFAULT 0,
    dp_count integer DEFAULT 0,
    in_count integer DEFAULT 0,
    ch_count integer DEFAULT 0
);


ALTER TABLE public.wordcounts_w OWNER TO hippa_wr;

--
-- TOC entry 17080 (class 0 OID 241034)
-- Dependencies: 3714
-- Data for Name: wordcounts_w; Type: TABLE DATA; Schema: public; Owner: hippa_wr
--

COPY public.wordcounts_w (entry_name, total_count, gr_count, lt_count, dp_count, in_count, ch_count) FROM stdin;
with	193	3	0	0	97	93
wilhelm	176	1	0	0	171	4
widerecus	1	0	0	0	0	1
wlzt	3	3	0	0	0	0
wassersüchtigen	1	0	0	0	0	1
wehrli	107	107	0	0	0	0
words	5	2	0	0	1	2
which	17	2	0	0	7	8
wachsmuth	28	28	0	0	0	0
warcianus	1	0	0	0	0	1
worn	11	0	0	0	11	0
wchr	295	0	0	295	0	0
wagner	10	10	0	0	0	0
w	843	826	0	1	7	9
woodhead	12	0	0	0	11	1
willelmus	46	0	0	0	0	46
wirunt	2	0	0	0	0	2
wendl	64	64	0	0	0	0
wd	24	24	0	0	0	0
wa–ri–mi–yo–ne	2	0	0	0	2	0
wo–le	1	0	0	0	1	0
wo–sἱ	1	0	0	0	1	0
within	23	0	0	0	20	3
wreath	63	0	0	0	46	17
walbank	10	0	0	0	10	0
walz	50	50	0	0	0	0
wendel	11	11	0	0	0	0
waltburgis	2	0	0	0	0	2
wobst	6	6	0	0	0	0
woodward	22	0	0	0	22	0
wellm	16	16	0	0	0	0
worteego	1	0	0	0	0	1
wilamowitz	20	19	0	0	1	0
wil	67	67	0	0	0	0
whether	7	0	0	0	7	0
werfer	41	41	0	0	0	0
wernher	2	0	0	0	0	2
were	4	2	0	0	1	1
wohl	13	8	0	0	4	1
wenige	1	1	0	0	0	0
wormacia	6	0	0	0	0	6
willibrordi	4	0	0	0	0	4
wi––ma–pa–sa–mo	1	0	0	0	1	0
wurde	2	1	0	0	1	0
wünsch	11	7	0	0	4	0
wellmann	16	16	0	0	0	0
willehelm	3	0	0	0	0	3
wy	3	3	0	0	0	0
wichmanus	1	0	0	0	0	1
witica	1	0	0	0	0	1
wyss	48	48	0	0	0	0
werden	3	3	0	0	0	0
walachfredi	2	0	0	0	0	2
werkzeichen	8	0	0	0	8	0
we	23	19	0	0	4	0
wessel	9	1	0	0	0	8
wiligelme	1	0	0	0	0	1
wendung	1	1	0	0	0	0
willelmi	18	0	0	0	0	18
warnerius	1	0	0	0	0	1
wilam	8	8	0	0	0	0
wormatia	3	0	0	0	0	3
waduulfo	6	0	0	6	0	0
wr	5	0	0	0	0	5
wlyšr	3	0	0	0	0	3
wignandus	2	0	0	0	0	2
wi	15	11	0	0	1	3
wachsm	23	23	0	0	0	0
willelma	2	0	0	0	0	2
west	30	26	0	0	2	2
wa–na–sa–se	7	0	0	0	7	0
weinmelchisedec	1	0	0	0	0	1
wilielmi	11	0	0	0	0	11
wštym	3	0	0	0	0	3
wimmer	23	23	0	0	0	0
wall	12	1	0	0	11	0
wort	1	0	0	0	0	1
widekini	1	0	0	0	0	1
who	2	0	0	0	0	2
warns	1	0	0	0	0	1
without	4	1	0	0	3	0
wal	25	25	0	0	0	0
wo–i–ko–i	7	0	0	0	7	0
willelmot	2	0	0	0	0	2
widekino	1	0	0	0	0	1
w/	40	0	0	0	40	0
wictimilus	1	0	0	0	0	1
war	6	2	0	0	1	3
worden	3	1	0	0	2	0
weltere	2	0	0	0	0	2
wxayyayb	3	3	0	0	0	0
wigfride	1	0	0	0	0	1
wie	17	11	0	0	5	1
wien	11	11	0	0	0	0
weights	1	0	0	0	1	0
willibirg	1	0	0	0	0	1
widbertus	2	0	0	0	0	2
wargānduht	1	0	0	0	0	1
wo	11	6	0	0	4	1
we–te–i	13	0	0	0	13	0
woentra	1	0	0	0	0	1
wolfhelmus	1	0	0	0	0	1
welter	2	0	0	0	2	0
woring	1	0	0	0	0	1
worringen	1	0	0	0	0	1
winged	1	0	0	0	1	0
wšmwl	1	0	0	0	0	1
william	2	2	0	0	0	0
warentrudis	4	0	0	0	0	4
wa–li–ka	23	0	0	0	23	0
waeschke	8	8	0	0	0	0
weibliche	5	0	0	0	0	5
wormatiensium	4	0	0	0	0	4
wisgoz	4	0	0	0	0	4
wo–i	2	0	0	0	2	0
widargildus	2	0	0	0	0	2
waldomeris	2	0	0	0	0	2
wtms	1	0	0	0	0	1
weiht	1	0	0	0	1	0
westermann	6	6	0	0	0	0
woman	4	0	0	0	3	1
widegouo	1	0	0	0	0	1
wallies	22	22	0	0	0	0
wo–i–no	1	0	0	0	1	0
we–to–se	2	0	0	0	2	0
wilgelmum	2	0	0	0	0	2
wa	26	15	0	0	1	10
wo–se	2	0	0	0	2	0
wyttenb	9	9	0	0	0	0
we–ro–se–a–po–i–	1	0	0	0	1	0
wbkry	1	0	0	0	1	0
wolbero	3	0	0	0	0	3
wlielmus	1	0	0	0	0	1
wallonis	1	0	0	0	0	1
wo–ino	1	0	0	0	1	0
walbanks	1	0	0	0	1	0
we–te–o–se	6	0	0	0	6	0
wolcenik	1	0	0	0	0	1
warinus	1	0	0	0	0	1
walburgis	2	0	0	0	0	2
wadamirus	1	0	0	0	0	1
wife	3	0	0	0	1	2
walpurgis	1	0	0	0	0	1
wido	4	0	0	0	0	4
wesp	3	3	0	0	0	0
wormatienses	3	0	0	0	0	3
wismodus	1	0	0	0	0	1
wlznsuλx	1	1	0	0	0	0
wirceberc	1	0	0	0	0	1
wormatiensis	11	0	0	0	0	11
wieder	1	0	0	0	0	1
werdo	4	0	0	0	0	4
wdyl	3	0	0	0	3	0
wšlwm	2	0	0	0	0	2
wolpertum	1	0	0	0	0	1
waltrudis	2	0	0	0	0	2
wa–sa	1	0	0	0	1	0
wya	7	7	0	0	0	0
waltherus	8	0	0	0	0	8
we–ke	1	0	0	0	1	0
weckl	9	9	0	0	0	0
w=chap	3	3	0	0	0	0
walter	2	0	0	0	2	0
widonis	5	0	0	0	0	5
witgario	1	0	0	0	0	1
wernerus	1	0	0	0	0	1
winckelm	10	10	0	0	0	0
worhte	3	0	0	0	0	3
wlz	1	1	0	0	0	0
wattenhein	1	0	0	0	0	1
wernherus	6	0	0	0	0	6
willeburgis	1	0	0	0	0	1
wiboradȩ	2	0	0	0	0	2
willelm	7	0	0	0	0	7
wi–ti–le–ra–nu	1	0	0	0	1	0
wernheri	1	0	0	0	0	1
wulfrici	1	0	0	0	0	1
weihnachten	8	0	0	0	0	8
weggebröckelt	1	0	0	0	1	0
willigisus	4	0	0	0	0	4
willigisi	1	0	0	0	0	1
willibrordus	2	0	0	0	0	2
wenrada	1	0	0	0	0	1
whale	1	0	0	0	0	1
watzinger	1	0	0	0	1	0
wuensch	2	2	0	0	0	0
wirk	1	1	0	0	0	0
written	3	0	0	0	3	0
wankel	4	0	0	0	4	0
witterit	1	0	0	1	0	0
wilgelm	1	0	0	0	0	1
wiltrudis	2	0	0	0	0	2
wormaciensi	2	0	0	0	0	2
wilhelmo	3	0	0	0	0	3
wolfram	2	0	0	0	0	2
wytt	3	3	0	0	0	0
waltarii	1	0	0	0	0	1
writing	2	0	0	0	2	0
walthero	1	0	0	0	0	1
wilhem	7	0	0	0	7	0
wheel–cross	2	0	0	0	0	2
weissenburg	2	0	0	0	0	2
westerm	5	5	0	0	0	0
wϲ	3	3	0	0	0	0
werf	18	18	0	0	0	0
weomadus	2	0	0	0	0	2
woher	1	1	0	0	0	0
wezzel	1	0	0	0	0	1
waren	2	0	0	0	0	2
was	11	2	0	0	6	3
willimar	4	0	0	0	0	4
wxaxcyya	2	2	0	0	0	0
weitere	3	1	0	0	2	0
wandelberc	1	0	0	0	0	1
wappen	7	0	0	0	0	7
wgl	3	3	0	0	0	0
wimari	2	0	0	0	0	2
walathini	1	0	0	0	0	1
wlabenius	1	0	0	0	0	1
wiborada	2	0	0	0	0	2
wοάϲονι	1	0	0	0	1	0
withe	2	0	0	0	0	2
wörter	1	0	0	0	1	0
wabuetusus	1	0	0	0	0	1
wl	3	0	0	0	0	3
waldafo	2	0	0	0	0	2
wormatiensibus	1	0	0	0	0	1
wescheri	2	2	0	0	0	0
wirtnwerg	1	0	0	0	0	1
wormacensis	1	0	0	0	0	1
word	3	0	0	0	3	0
wellelmus	1	0	0	0	0	1
we–re–ta–se	2	0	0	0	2	0
winlogee	1	0	0	0	0	1
winlowen	1	0	0	0	0	1
willibrorde	1	0	0	0	0	1
wealth	1	0	0	0	1	0
wolfius	2	2	0	0	0	0
wirceburgensi	2	0	0	0	0	2
wilhelmus	8	0	0	0	0	8
weiteres	1	0	0	0	1	0
wifredi	2	0	0	0	0	2
werinherus	1	0	0	0	0	1
wtwrh	2	0	0	0	0	2
waltheri	3	0	0	0	0	3
wade–gery	6	0	0	0	6	0
wa–na–xe	3	0	0	0	3	0
we–po	1	0	0	0	1	0
we–i–se–se	1	0	0	0	1	0
wgdwnt	2	0	0	0	0	2
wxcy	1	1	0	0	0	0
wü	9	9	0	0	0	0
worte	4	3	0	0	0	1
wa–hamsimia	1	0	0	0	0	1
wa–saba	1	0	0	0	0	1
wolska–conus	3	0	0	0	2	1
wale	2	0	0	0	0	2
wölfflin	1	1	0	0	0	0
wzhalle	1	0	0	0	1	0
wichfrido	2	0	0	0	0	2
widerlegungen	1	1	0	0	0	0
wxaya	2	2	0	0	0	0
wo–ru–to	1	0	0	0	1	0
winzeburc	2	0	0	0	0	2
wx	1	1	0	0	0	0
wolfg	1	1	0	0	0	0
weiteren	3	0	0	0	3	0
witgenstein	1	0	0	0	0	1
wsb	1	0	0	0	0	1
wearing	2	0	0	0	2	0
wirundi	2	0	0	0	0	2
wine	2	0	0	0	2	0
wormaciensis	2	0	0	0	0	2
wimm	8	8	0	0	0	0
wormatiensi	5	0	0	0	0	5
weight	2	0	0	0	2	0
wachs	2	2	0	0	0	0
wbisyyayb	1	1	0	0	0	0
weiterer	3	0	0	0	3	0
we–––ke–	1	0	0	0	1	0
wormacianis	1	0	0	0	0	1
wini	1	0	0	0	0	1
wag	1	0	0	0	0	1
wurd	1	0	0	0	0	1
wowemus	1	0	0	0	0	1
walherum	1	0	0	0	0	1
wileca	2	0	0	0	0	2
wlznsu	1	1	0	0	0	0
wirzburgensis	1	0	0	0	0	1
wespanus	1	0	0	0	0	1
werdina	1	0	0	0	0	1
wilelmus	2	0	0	0	0	2
wardradus	1	0	0	0	0	1
willero	2	0	0	0	0	2
westerink	3	3	0	0	0	0
weiltingen	1	0	0	0	0	1
walpertus	4	0	0	0	0	4
wi–	1	0	0	0	1	0
wodurch	2	2	0	0	0	0
wird	4	2	0	0	0	2
wibaldo	2	0	0	0	0	2
waltero	2	0	0	0	0	2
wo––pu–lo–se	1	0	0	0	1	0
walterius	1	0	0	0	0	1
warrior	4	0	0	0	3	1
willeman	1	0	0	0	0	1
wezel	1	0	0	0	0	1
wreaths	2	0	0	0	2	0
welche	5	0	0	0	0	5
wormuciensis	2	0	0	0	0	2
wer	3	2	0	0	0	1
widerici	1	0	0	0	0	1
wiliarit	3	0	0	3	0	0
wilhe|lmus	1	0	0	0	0	1
willem	1	0	0	0	0	1
wormell	2	2	0	0	0	0
wifredus	2	0	0	0	0	2
willigise	2	0	0	0	0	2
wxcyayb	1	1	0	0	0	0
wlynw	2	0	0	0	0	2
wendland	2	2	0	0	0	0
wenceslai	2	0	0	0	0	2
wali–ka	2	0	0	0	2	0
wiedergegebene	1	0	0	0	0	1
walli	1	0	0	0	0	1
wxayya	2	2	0	0	0	0
wylif	1	0	0	0	0	1
wormatiani	4	0	0	0	0	4
wmarg	3	3	0	0	0	0
we–ka–te–ti–po–si–ro–ti	1	0	0	0	1	0
weapons	1	0	0	0	1	0
wileyci	1	0	0	0	0	1
wileman	1	0	0	0	0	1
wilemar	1	0	0	0	0	1
wadouulfo	1	0	0	1	0	0
womari	1	0	0	0	0	1
wleder	1	0	0	0	0	1
wizunburg	2	0	0	0	0	2
wigberto	1	0	0	0	0	1
wide	2	0	0	0	2	0
wissel	1	0	0	0	0	1
weiter	2	0	0	0	1	1
w-	1	0	0	0	0	1
wirina	1	0	0	0	0	1
wiss	2	2	0	0	0	0
westliches	1	0	0	0	0	1
willerus	2	0	0	0	0	2
wezelin	1	0	0	0	0	1
wahdi–hi	1	0	0	0	0	1
winihardi	1	0	0	0	0	1
wyrh	1	0	0	0	0	1
walker	1	0	0	0	1	0
wo–ro–i–ko	1	0	0	0	1	0
weilius	1	1	0	0	0	0
wo–i–	1	0	0	0	1	0
wess	1	1	0	0	0	0
waelkens	1	0	0	0	1	0
whitehead	4	0	0	0	4	0
wolfra-	1	0	0	0	0	1
wesseling	1	1	0	0	0	0
wnus	1	0	0	0	0	1
welchen	2	0	0	0	0	2
wächtersepulcrum	1	0	0	0	0	1
wolfii	1	1	0	0	0	0
walthere	1	0	0	0	0	1
wizenburgensis	1	0	0	0	0	1
wahrscheinlich	1	1	0	0	0	0
walahfredus	2	0	0	0	0	2
wolfgang	2	0	0	0	0	2
wenkebachpfaff	1	1	0	0	0	0
wigbertus	1	0	0	0	0	1
wrob	2	2	0	0	0	0
warriors	1	0	0	0	1	0
wormaciam	1	0	0	0	0	1
wagendenror	2	0	0	0	0	2
walpertii	1	0	0	0	0	1
witellius	1	0	0	0	0	1
weihung	2	0	0	0	2	0
walburge	2	0	0	0	0	2
well	1	0	0	0	0	1
wiboradae	1	0	0	0	0	1
weiterhin	1	0	0	0	1	0
wilileua	1	0	0	1	0	0
walzii	2	2	0	0	0	0
würzburg	1	0	0	0	1	0
wiger	2	0	0	0	0	2
weluar	1	0	0	0	0	1
wilhelms	1	0	0	0	1	0
waltz	1	1	0	0	0	0
wardus	1	0	0	0	0	1
wylagahis	1	0	0	0	0	1
wis	2	0	0	0	0	2
warnerii	1	0	0	0	0	1
wenn	3	3	0	0	0	0
womarus	1	0	0	0	0	1
wigberhtus	1	0	0	0	0	1
wesel	2	2	0	0	0	0
wisschel	1	0	0	0	0	1
wirtenberge	1	0	0	0	0	1
wilgisus	2	0	0	0	0	2
winterschozze	1	0	0	0	0	1
walfredi	2	0	0	0	0	2
wowimus	1	0	0	0	0	1
wace	1	0	0	0	1	0
wxaxcyyayb	2	2	0	0	0	0
walerici	1	0	0	0	0	1
wyaxa	1	1	0	0	0	0
wircean	1	0	0	0	0	1
we–re–se–e	2	0	0	0	2	0
wolfradus	2	0	0	0	0	2
wenkebach	1	1	0	0	0	0
wiggonis	1	0	0	0	0	1
waes	3	0	0	0	0	3
wolfharti	1	0	0	0	0	1
weisheit	2	0	0	0	0	2
wilhelmi	1	0	0	0	0	1
wind	1	0	0	0	1	0
w/photo	3	0	0	0	3	0
wigfus	1	0	0	0	0	1
willibaldi	1	0	0	0	0	1
widone	2	0	0	0	0	2
what	3	0	0	0	3	0
wallis	1	1	0	0	0	0
wytn	2	0	0	0	2	0
winck	5	5	0	0	0	0
wililelmus	1	0	0	0	0	1
waduulfi	1	0	0	1	0	0
weomado	1	0	0	0	0	1
wa–li	2	0	0	0	2	0
wick–snuffer	1	0	0	0	0	1
wenk	4	4	0	0	0	0
willelmum	4	0	0	0	0	4
wormacie	2	0	0	0	0	2
wholly	1	0	0	0	1	0
winstedt	1	1	0	0	0	0
wizeburgense	1	0	0	0	0	1
walafrid	2	0	0	0	0	2
wentz	2	2	0	0	0	0
worauf	1	1	0	0	0	0
walking	1	0	0	0	0	1
walpodo	3	0	0	0	0	3
warmundi	1	0	0	0	0	1
wililiwae	1	0	0	1	0	0
wiligelmus	1	0	0	0	0	1
wωιϲ	1	0	0	0	1	0
wri	1	0	0	0	0	1
wa–na–ka–sa–ko–ra–se	1	0	0	0	1	0
wes	1	0	0	0	0	1
wilelmi	2	0	0	0	0	2
wicelino	1	0	0	0	0	1
witernensi	1	0	0	0	0	1
weihe	1	0	0	0	0	1
walcher	1	0	0	0	0	1
wecklinianam	1	1	0	0	0	0
weissagungen	1	0	0	0	0	1
wlfmaeg	1	0	0	0	0	1
wlfrici	1	0	0	0	0	1
wimara	1	0	0	0	0	1
warmundus	1	0	0	0	0	1
wlzxsubsu	1	1	0	0	0	0
wilelm	1	0	0	0	0	1
wudu	1	0	0	0	0	1
warmandesheim⌋	2	0	0	0	0	2
weinberg	1	0	0	0	1	0
we–li–pa	1	0	0	0	1	0
worteχριϲτόϲ	1	0	0	0	0	1
wedge–shaped	1	0	0	0	1	0
wernhero	2	0	0	0	0	2
woth-	1	0	0	0	0	1
westenberger	1	1	0	0	0	0
willelmo	3	0	0	0	0	3
weit	1	1	0	0	0	0
wolfiani	1	1	0	0	0	0
witnesses	1	0	0	0	1	0
witardus	1	0	0	0	0	1
wiebliche	1	0	0	0	0	1
wimerskirch	1	0	0	0	0	1
we–pi–ya	1	0	0	0	1	0
widh	1	0	0	0	0	1
wironis	2	0	0	0	0	2
wendet	3	3	0	0	0	0
winici	1	0	0	0	0	1
walburgae	1	0	0	0	0	1
wirtenberg	1	0	0	0	0	1
worp	1	1	0	0	0	0
wohte	2	0	0	0	0	2
wirtzburgum	1	0	0	0	0	1
wu	2	1	0	0	0	1
wiseman	1	0	0	0	1	0
wasco	1	0	0	0	0	1
wn	1	1	0	0	0	0
wiberade	2	0	0	0	0	2
welcher	1	0	0	0	0	1
wne	1	0	0	0	0	1
wilke	1	1	0	0	0	0
wick–snuffers	1	0	0	0	0	1
wöchnerin	1	0	0	0	0	1
wnglsts	1	0	0	0	0	1
wb	1	1	0	0	0	0
witizani	1	0	0	0	0	1
wart	1	0	0	0	0	1
wolgeborne	1	0	0	0	0	1
winfride	1	0	0	0	0	1
witwen	1	0	0	0	0	1
wirzburgi	1	0	0	0	0	1
walde	1	0	0	0	0	1
wölfen	1	0	0	0	0	1
wolken	2	0	0	0	0	2
willis	1	1	0	0	0	0
wadha–hu	1	0	0	0	0	1
wo–i–ko–se	1	0	0	0	1	0
watheim	1	0	0	0	0	1
wattenheim	1	0	0	0	0	1
wrohte	1	0	0	0	0	1
whiston	1	1	0	0	0	0
willipaldo	1	0	0	0	0	1
wo–i–wa–ni–ya–se	1	0	0	0	1	0
waldo	2	0	0	0	0	2
wlztλb	1	1	0	0	0	0
wichmannus	1	0	0	0	0	1
wὁ	1	0	0	0	1	0
wlbnyhwn	1	0	0	0	0	1
wlbn	1	0	0	0	0	1
wiueraht	1	0	0	0	0	1
weihnachtstag	1	0	0	0	0	1
wujûd–humâ	1	0	0	0	0	1
wistremirus	1	0	0	0	0	1
winibaldi	1	0	0	0	0	1
wwxa	1	1	0	0	0	0
winter	1	0	0	0	1	0
wolfhart	1	0	0	0	0	1
witardi	1	0	0	0	0	1
willienant	1	0	0	1	0	0
wamba	2	0	0	0	0	2
werdonis	1	0	0	0	0	1
westermanni	1	1	0	0	0	0
worshipper	1	0	0	0	0	1
wxc	2	2	0	0	0	0
wa–la–ka–ni–o	1	0	0	0	1	0
wrote	1	0	0	0	0	1
wolf	1	1	0	0	0	0
worrd	1	0	0	0	0	1
welles	1	0	0	0	1	0
wuorh|t	1	0	0	0	0	1
wilielmo	1	0	0	0	0	1
waxc	2	2	0	0	0	0
wlqyr	2	0	0	0	0	2
wirana	1	0	0	0	0	1
wirceburgensis	1	0	0	0	0	1
willemus	1	0	0	0	0	1
wiffreti	1	0	0	0	0	1
wytles	1	0	0	0	0	1
woluisgazen	1	0	0	0	0	1
womontis	1	0	0	0	0	1
widecho	1	0	0	0	0	1
widonem	1	0	0	0	0	1
wilelmo	1	0	0	0	0	1
walburgi	1	0	0	0	0	1
wernhardus	2	0	0	0	0	2
wariento	1	0	0	0	0	1
wozu	1	1	0	0	0	0
wandung	1	0	0	0	0	1
walfisch	2	0	0	0	0	2
wolfium	1	1	0	0	0	0
wurzeburc	1	0	0	0	0	1
wolferado	1	0	0	0	0	1
weibes	1	0	0	0	0	1
wortes	1	1	0	0	0	0
wamarg	1	1	0	0	0	0
wegen	1	1	0	0	0	0
wilielemus	1	0	0	0	0	1
wxxa	1	1	0	0	0	0
wiberti	1	0	0	0	0	1
wala|munster	1	0	0	0	0	1
wlzub*	1	1	0	0	0	0
wistremius	1	0	0	0	0	1
w﹨l	1	0	0	0	0	1
while	2	0	0	0	0	2
wangen	1	0	0	0	0	1
would	1	0	0	0	1	0
wigfrid	1	0	0	0	0	1
wihen	1	0	0	0	0	1
walburg	1	0	0	0	0	1
wickens	1	0	0	0	1	0
war|enbertu|s	1	0	0	0	0	1
willer	1	0	0	0	0	1
willehild	1	0	0	0	0	1
wadard	1	0	0	0	0	1
weibliches	1	0	0	0	0	1
württemberg–grüningen	1	0	0	0	0	1
wiro	1	0	0	0	0	1
weinheim	1	0	0	0	0	1
wlneratum	1	0	0	0	0	1
wiedergiebt	1	0	0	0	0	1
wudeman	1	0	0	0	0	1
wrobel	1	1	0	0	0	0
wescher	1	1	0	0	0	0
wyrican	1	0	0	0	0	1
waitz	1	1	0	0	0	0
wxy	1	1	0	0	0	0
wiltelmini	1	0	0	0	0	1
willelmini	1	0	0	0	0	1
we–i–ko–na	1	0	0	0	1	0
wilielmus	1	0	0	0	0	1
willebrordi	1	0	0	0	0	1
wilbernus	1	0	0	0	0	1
we–ro–ko–ke–reti	1	0	0	0	1	0
wiederadam	1	0	0	0	0	1
willemsen	1	0	0	0	1	0
weisen	1	0	0	0	0	1
we|zilo	1	0	0	0	0	1
wielme	1	0	0	0	0	1
wyttenbach	1	1	0	0	0	0
wp	1	1	0	0	0	0
wasconia	1	0	0	0	0	1
wligue	1	0	0	0	0	1
warth	1	0	0	0	0	1
willes	1	0	0	0	0	1
wetsch	1	1	0	0	0	0
\.


--
-- TOC entry 16949 (class 1259 OID 241043)
-- Name: wcindex_w; Type: INDEX; Schema: public; Owner: hippa_wr
--

CREATE UNIQUE INDEX wcindex_w ON public.wordcounts_w USING btree (entry_name);


--
-- TOC entry 17086 (class 0 OID 0)
-- Dependencies: 3714
-- Name: TABLE wordcounts_w; Type: ACL; Schema: public; Owner: hippa_wr
--

GRANT SELECT ON TABLE public.wordcounts_w TO hippa_rd;


-- Completed on 2021-05-17 21:30:09 UTC

--
-- PostgreSQL database dump complete
--

