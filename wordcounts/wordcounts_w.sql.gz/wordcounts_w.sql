--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5 (Ubuntu 11.5-0ubuntu0.19.04.1)
-- Dumped by pg_dump version 11.5 (Ubuntu 11.5-0ubuntu0.19.04.1)

-- Started on 2019-10-09 15:22:39 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 3376 (class 1259 OID 197089)
-- Name: wordcounts_w; Type: TABLE; Schema: public; Owner: hippa_wr
--

CREATE TABLE public.wordcounts_w (
    entry_name character varying(64),
    total_count integer DEFAULT 0,
    gr_count integer DEFAULT 0,
    lt_count integer DEFAULT 0,
    dp_count integer DEFAULT 0,
    in_count integer DEFAULT 0,
    ch_count integer DEFAULT 0
);


ALTER TABLE public.wordcounts_w OWNER TO hippa_wr;

--
-- TOC entry 17020 (class 0 OID 197089)
-- Dependencies: 3376
-- Data for Name: wordcounts_w; Type: TABLE DATA; Schema: public; Owner: hippa_wr
--

COPY public.wordcounts_w (entry_name, total_count, gr_count, lt_count, dp_count, in_count, ch_count) FROM stdin;
within	23	0	0	0	20	3
wreath	63	0	0	0	46	17
with	193	3	0	0	97	93
w	843	826	0	1	7	9
wa	26	15	0	0	1	10
willelmus	46	0	0	0	0	46
werfer	41	41	0	0	0	0
weihung	2	0	0	0	2	0
wyss	48	48	0	0	0	0
wo–ru–to	1	0	0	0	1	0
werkzeichen	8	0	0	0	8	0
witnesses	1	0	0	0	1	0
wisgoz	4	0	0	0	0	4
wchr	295	0	0	295	0	0
westermann	6	6	0	0	0	0
wizunburg	2	0	0	0	0	2
wil	67	67	0	0	0	0
wa–li–ka	23	0	0	0	23	0
wifredi	2	0	0	0	0	2
wormatiensi	5	0	0	0	0	5
wo–ino	1	0	0	0	1	0
waes	3	0	0	0	0	3
walahfredus	2	0	0	0	0	2
wytt	3	3	0	0	0	0
wagner	10	10	0	0	0	0
walz	50	50	0	0	0	0
wd	24	24	0	0	0	0
wlynw	2	0	0	0	0	2
wl	3	0	0	0	0	3
which	17	2	0	0	7	8
wlqyr	2	0	0	0	0	2
wehrli	107	107	0	0	0	0
wilhelm	176	1	0	0	171	4
wöchnerin	1	0	0	0	0	1
we–ro–ko–ke–reti	1	0	0	0	1	0
wal	25	25	0	0	0	0
woodward	22	0	0	0	22	0
wachsmuth	28	28	0	0	0	0
wormell	2	2	0	0	0	0
wormatiani	4	0	0	0	0	4
wimmer	23	23	0	0	0	0
wlzxsubsu	1	1	0	0	0	0
walpertus	4	0	0	0	0	4
willelmi	18	0	0	0	0	18
wilamowitz	20	19	0	0	1	0
wircean	1	0	0	0	0	1
woodhead	12	0	0	0	11	1
wigfus	1	0	0	0	0	1
wü	9	9	0	0	0	0
werf	18	18	0	0	0	0
wdyl	3	0	0	0	3	0
wi	15	11	0	0	1	3
we–te–i	13	0	0	0	13	0
wgdwnt	2	0	0	0	0	2
wardus	1	0	0	0	0	1
wnglsts	1	0	0	0	0	1
weitere	3	1	0	0	2	0
we	23	19	0	0	4	0
wrob	2	2	0	0	0	0
walburge	2	0	0	0	0	2
wilhem	7	0	0	0	7	0
wadard	1	0	0	0	0	1
wyrh	1	0	0	0	0	1
wo	11	6	0	0	4	1
war	6	2	0	0	1	3
wolbero	3	0	0	0	0	3
wirceburgensi	2	0	0	0	0	2
withe	2	0	0	0	0	2
west	30	26	0	0	2	2
wimm	8	8	0	0	0	0
wo–i–ko–se	1	0	0	0	1	0
wohl	13	8	0	0	4	1
wie	17	11	0	0	5	1
wünsch	11	7	0	0	4	0
wendet	3	3	0	0	0	0
worp	1	1	0	0	0	0
wachsm	23	23	0	0	0	0
written	3	0	0	0	3	0
welche	5	0	0	0	0	5
was	11	2	0	0	6	3
wi––ma–pa–sa–mo	1	0	0	0	1	0
waitz	1	1	0	0	0	0
whitehead	4	0	0	0	4	0
walherum	1	0	0	0	0	1
weissenburg	2	0	0	0	0	2
welter	2	0	0	0	2	0
wri	1	0	0	0	0	1
w=chap	3	3	0	0	0	0
walburgi	1	0	0	0	0	1
wyttenb	9	9	0	0	0	0
wolf	1	1	0	0	0	0
weckl	9	9	0	0	0	0
westerm	5	5	0	0	0	0
walfredi	2	0	0	0	0	2
wobst	6	6	0	0	0	0
without	4	1	0	0	3	0
words	5	2	0	0	1	2
wormuciensis	2	0	0	0	0	2
wuorh|t	1	0	0	0	0	1
worhte	3	0	0	0	0	3
wendl	64	64	0	0	0	0
wilelmi	2	0	0	0	0	2
w/	40	0	0	0	40	0
wissel	1	0	0	0	0	1
we–––ke–	1	0	0	0	1	0
weihnachten	8	0	0	0	0	8
wibaldo	2	0	0	0	0	2
waltero	2	0	0	0	0	2
wormaciensi	2	0	0	0	0	2
wilhelmo	3	0	0	0	0	3
woth-	1	0	0	0	0	1
wilam	8	8	0	0	0	0
wido	4	0	0	0	0	4
winck	5	5	0	0	0	0
wilhelmus	8	0	0	0	0	8
willimar	4	0	0	0	0	4
wiebliche	1	0	0	0	0	1
woman	4	0	0	0	3	1
wiedergegebene	1	0	0	0	0	1
wxaxcyyayb	2	2	0	0	0	0
wernherus	6	0	0	0	0	6
were	4	2	0	0	1	1
worn	11	0	0	0	11	0
wictimilus	1	0	0	0	0	1
wall	12	1	0	0	11	0
wilielmi	11	0	0	0	0	11
widargildus	2	0	0	0	0	2
walburgis	2	0	0	0	0	2
wormatiensis	11	0	0	0	0	11
wileman	1	0	0	0	0	1
wilemar	1	0	0	0	0	1
wo–se	2	0	0	0	2	0
willelmot	2	0	0	0	0	2
wisschel	1	0	0	0	0	1
wodurch	2	2	0	0	0	0
wird	4	2	0	0	0	2
waltheri	3	0	0	0	0	3
wxc	2	2	0	0	0	0
wendland	2	2	0	0	0	0
wormacensis	1	0	0	0	0	1
wes	1	0	0	0	0	1
warentrudis	4	0	0	0	0	4
wolfra-	1	0	0	0	0	1
wilelmus	2	0	0	0	0	2
wifredus	2	0	0	0	0	2
wiltelmini	1	0	0	0	0	1
willelmini	1	0	0	0	0	1
we–re–ta–se	2	0	0	0	2	0
wo–i	2	0	0	0	2	0
wallies	22	22	0	0	0	0
warth	1	0	0	0	0	1
weibliche	5	0	0	0	0	5
wachs	2	2	0	0	0	0
we–i–ko–na	1	0	0	0	1	0
wirana	1	0	0	0	0	1
weights	1	0	0	0	1	0
walafrid	2	0	0	0	0	2
wade–gery	6	0	0	0	6	0
wali–ka	2	0	0	0	2	0
while	2	0	0	0	0	2
who	2	0	0	0	0	2
wescheri	2	2	0	0	0	0
wolfharti	1	0	0	0	0	1
wileca	2	0	0	0	0	2
wappen	7	0	0	0	0	7
württemberg–grüningen	1	0	0	0	0	1
willer	1	0	0	0	0	1
willehild	1	0	0	0	0	1
wmarg	3	3	0	0	0	0
wismodus	1	0	0	0	0	1
weluar	1	0	0	0	0	1
wlznsuλx	1	1	0	0	0	0
wenk	4	4	0	0	0	0
weihe	1	0	0	0	0	1
walfisch	2	0	0	0	0	2
wörter	1	0	0	0	1	0
wistremirus	1	0	0	0	0	1
wy	3	3	0	0	0	0
willelmo	3	0	0	0	0	3
wickens	1	0	0	0	1	0
waltburgis	2	0	0	0	0	2
wo–i–no	1	0	0	0	1	0
we–to–se	2	0	0	0	2	0
weiteres	1	0	0	0	1	0
willibrordi	4	0	0	0	0	4
westermanni	1	1	0	0	0	0
wlztλb	1	1	0	0	0	0
wellmann	16	16	0	0	0	0
wohte	2	0	0	0	0	2
wormatiensium	4	0	0	0	0	4
wessel	9	1	0	0	0	8
wilgelmum	2	0	0	0	0	2
wilelmo	1	0	0	0	0	1
weilius	1	1	0	0	0	0
wormatienses	3	0	0	0	0	3
wien	11	11	0	0	0	0
wx	1	1	0	0	0	0
wironis	2	0	0	0	0	2
wormacia	6	0	0	0	0	6
westenberger	1	1	0	0	0	0
walking	1	0	0	0	0	1
wirzburgensis	1	0	0	0	0	1
wendel	11	11	0	0	0	0
widonis	5	0	0	0	0	5
wolfius	2	2	0	0	0	0
wangen	1	0	0	0	0	1
wolfram	2	0	0	0	0	2
worshipper	1	0	0	0	0	1
wesp	3	3	0	0	0	0
wo–i–ko–i	7	0	0	0	7	0
warmandesheim⌋	2	0	0	0	0	2
william	2	2	0	0	0	0
wala|munster	1	0	0	0	0	1
weibliches	1	0	0	0	0	1
word	3	0	0	0	3	0
werdina	1	0	0	0	0	1
wyttenbach	1	1	0	0	0	0
wa–na–sa–se	7	0	0	0	7	0
wytn	2	0	0	0	2	0
willigisus	4	0	0	0	0	4
we–pi–ya	1	0	0	0	1	0
westerink	3	3	0	0	0	0
wheel–cross	2	0	0	0	0	2
willelmum	4	0	0	0	0	4
wnus	1	0	0	0	0	1
worte	4	3	0	0	0	1
waeschke	8	8	0	0	0	0
wesseling	1	1	0	0	0	0
welchen	2	0	0	0	0	2
weiter	2	0	0	0	1	1
wtwrh	2	0	0	0	0	2
wr	5	0	0	0	0	5
wštym	3	0	0	0	0	3
waltz	1	1	0	0	0	0
wiss	2	2	0	0	0	0
wellm	16	16	0	0	0	0
weltere	2	0	0	0	0	2
walbank	10	0	0	0	10	0
wxayyayb	3	3	0	0	0	0
werinherus	1	0	0	0	0	1
wiberade	2	0	0	0	0	2
wetsch	1	1	0	0	0	0
winter	1	0	0	0	1	0
winckelm	10	10	0	0	0	0
wirceberc	1	0	0	0	0	1
wiboradȩ	2	0	0	0	0	2
willebrordi	1	0	0	0	0	1
weiteren	3	0	0	0	3	0
wililiwae	1	0	0	1	0	0
whether	7	0	0	0	7	0
wsb	1	0	0	0	0	1
willibrorde	1	0	0	0	0	1
wilielemus	1	0	0	0	0	1
wizenburgensis	1	0	0	0	0	1
waltherus	8	0	0	0	0	8
wilelm	1	0	0	0	0	1
wide	2	0	0	0	2	0
wyaxa	1	1	0	0	0	0
w/photo	3	0	0	0	3	0
widekino	1	0	0	0	0	1
willelm	7	0	0	0	0	7
wxaya	2	2	0	0	0	0
wine	2	0	0	0	2	0
well	1	0	0	0	0	1
wegen	1	1	0	0	0	0
wlielmus	1	0	0	0	0	1
wylif	1	0	0	0	0	1
whale	1	0	0	0	0	1
wormacie	2	0	0	0	0	2
willibrordus	2	0	0	0	0	2
wšlwm	2	0	0	0	0	2
wi–ti–le–ra–nu	1	0	0	0	1	0
wa–li	2	0	0	0	2	0
wrohte	1	0	0	0	0	1
wxayya	2	2	0	0	0	0
wgl	3	3	0	0	0	0
wolpertum	1	0	0	0	0	1
wer	3	2	0	0	0	1
wardradus	1	0	0	0	0	1
wozu	1	1	0	0	0	0
weomado	1	0	0	0	0	1
wealth	1	0	0	0	1	0
waldafo	2	0	0	0	0	2
weissagungen	1	0	0	0	0	1
wn	1	1	0	0	0	0
wirtenberg	1	0	0	0	0	1
wernhero	2	0	0	0	0	2
warrior	4	0	0	0	3	1
wlyšr	3	0	0	0	0	3
we–te–o–se	6	0	0	0	6	0
worrd	1	0	0	0	0	1
walter	2	0	0	0	2	0
wuensch	2	2	0	0	0	0
waduulfo	6	0	0	6	0	0
wirzburgi	1	0	0	0	0	1
wenn	3	3	0	0	0	0
wölfen	1	0	0	0	0	1
wϲ	3	3	0	0	0	0
wearing	2	0	0	0	2	0
wernher	2	0	0	0	0	2
warns	1	0	0	0	0	1
walker	1	0	0	0	1	0
wigberhtus	1	0	0	0	0	1
whiston	1	1	0	0	0	0
wiseman	1	0	0	0	1	0
wolferado	1	0	0	0	0	1
wp	1	1	0	0	0	0
wihen	1	0	0	0	0	1
wilgelm	1	0	0	0	0	1
wecklinianam	1	1	0	0	0	0
walthere	1	0	0	0	0	1
wšmwl	1	0	0	0	0	1
wife	3	0	0	0	1	2
wzhalle	1	0	0	0	1	0
what	3	0	0	0	3	0
werden	3	3	0	0	0	0
wenkebach	1	1	0	0	0	0
wasco	1	0	0	0	0	1
wiliarit	3	0	0	3	0	0
wleder	1	0	0	0	0	1
worteχριϲτόϲ	1	0	0	0	0	1
wankel	4	0	0	0	4	0
warcianus	1	0	0	0	0	1
waltarii	1	0	0	0	0	1
wolfradus	2	0	0	0	0	2
waldomeris	2	0	0	0	0	2
wichfrido	2	0	0	0	0	2
winged	1	0	0	0	1	0
waren	2	0	0	0	0	2
witterit	1	0	0	1	0	0
wiggonis	1	0	0	0	0	1
wentz	2	2	0	0	0	0
wiro	1	0	0	0	0	1
weomadus	2	0	0	0	0	2
witgenstein	1	0	0	0	0	1
wichmanus	1	0	0	0	0	1
waxc	2	2	0	0	0	0
wu	2	1	0	0	0	1
wellelmus	1	0	0	0	0	1
wlzt	3	3	0	0	0	0
widerlegungen	1	1	0	0	0	0
warinus	1	0	0	0	0	1
wa–na–xe	3	0	0	0	3	0
wezzel	1	0	0	0	0	1
witwen	1	0	0	0	0	1
wurde	2	1	0	0	1	0
wimara	1	0	0	0	0	1
wick–snuffer	1	0	0	0	0	1
wililelmus	1	0	0	0	0	1
wa–la–ka–ni–o	1	0	0	0	1	0
we–li–pa	1	0	0	0	1	0
wilbernus	1	0	0	0	0	1
worden	3	1	0	0	2	0
wya	7	7	0	0	0	0
weight	2	0	0	0	2	0
wernhardus	2	0	0	0	0	2
wandung	1	0	0	0	0	1
wagendenror	2	0	0	0	0	2
wesel	2	2	0	0	0	0
would	1	0	0	0	1	0
wimari	2	0	0	0	0	2
walerici	1	0	0	0	0	1
wolfium	1	1	0	0	0	0
war|enbertu|s	1	0	0	0	0	1
walbanks	1	0	0	0	1	0
wenige	1	1	0	0	0	0
winlogee	1	0	0	0	0	1
winlowen	1	0	0	0	0	1
wielme	1	0	0	0	0	1
widecho	1	0	0	0	0	1
wormacianis	1	0	0	0	0	1
weiht	1	0	0	0	1	0
waduulfi	1	0	0	1	0	0
walthero	1	0	0	0	0	1
wiger	2	0	0	0	0	2
walzii	2	2	0	0	0	0
wa–sa	1	0	0	0	1	0
willibaldi	1	0	0	0	0	1
witellius	1	0	0	0	0	1
wudu	1	0	0	0	0	1
widbertus	2	0	0	0	0	2
waldo	2	0	0	0	0	2
wirtenberge	1	0	0	0	0	1
wa–hamsimia	1	0	0	0	0	1
wa–saba	1	0	0	0	0	1
weinheim	1	0	0	0	0	1
wendung	1	1	0	0	0	0
waltrudis	2	0	0	0	0	2
wormatia	3	0	0	0	0	3
watzinger	1	0	0	0	1	0
wenrada	1	0	0	0	0	1
wizeburgense	1	0	0	0	0	1
warnerii	1	0	0	0	0	1
wieder	1	0	0	0	0	1
womontis	1	0	0	0	0	1
warnerius	1	0	0	0	0	1
wo––pu–lo–se	1	0	0	0	1	0
willehelm	3	0	0	0	0	3
wlneratum	1	0	0	0	0	1
wiligelmus	1	0	0	0	0	1
wreaths	2	0	0	0	2	0
wudeman	1	0	0	0	0	1
wiffreti	1	0	0	0	0	1
winibaldi	1	0	0	0	0	1
wandelberc	1	0	0	0	0	1
wormaciam	1	0	0	0	0	1
walcher	1	0	0	0	0	1
wwxa	1	1	0	0	0	0
willeburgis	1	0	0	0	0	1
weapons	1	0	0	0	1	0
witardi	1	0	0	0	0	1
we–ro–se–a–po–i–	1	0	0	0	1	0
wigbertus	1	0	0	0	0	1
weisen	1	0	0	0	0	1
willigise	2	0	0	0	0	2
wligue	1	0	0	0	0	1
wasconia	1	0	0	0	0	1
wernerus	1	0	0	0	0	1
weihnachtstag	1	0	0	0	0	1
wxcy	1	1	0	0	0	0
weibes	1	0	0	0	0	1
wargānduht	1	0	0	0	0	1
wallonis	1	0	0	0	0	1
widekini	1	0	0	0	0	1
wölfflin	1	1	0	0	0	0
widonem	1	0	0	0	0	1
weiterhin	1	0	0	0	1	0
wiligelme	1	0	0	0	0	1
wxy	1	1	0	0	0	0
walburgae	1	0	0	0	0	1
wigfrid	1	0	0	0	0	1
weisheit	2	0	0	0	0	2
warriors	1	0	0	0	1	0
wxcyayb	1	1	0	0	0	0
willes	1	0	0	0	0	1
wilielmus	1	0	0	0	0	1
wylagahis	1	0	0	0	0	1
willipaldo	1	0	0	0	0	1
widerecus	1	0	0	0	0	1
wale	2	0	0	0	0	2
wlzub*	1	1	0	0	0	0
walachfredi	2	0	0	0	0	2
walburg	1	0	0	0	0	1
w﹨l	1	0	0	0	0	1
wωιϲ	1	0	0	0	1	0
wolska–conus	3	0	0	0	2	1
winihardi	1	0	0	0	0	1
winstedt	1	1	0	0	0	0
wolfhelmus	1	0	0	0	0	1
willero	2	0	0	0	0	2
wedge–shaped	1	0	0	0	1	0
worauf	1	1	0	0	0	0
winici	1	0	0	0	0	1
wlz	1	1	0	0	0	0
willienant	1	0	0	1	0	0
wrobel	1	1	0	0	0	0
willemus	1	0	0	0	0	1
wbisyyayb	1	1	0	0	0	0
wis	2	0	0	0	0	2
wini	1	0	0	0	0	1
woluisgazen	1	0	0	0	0	1
wxaxcyya	2	2	0	0	0	0
wilileua	1	0	0	1	0	0
walpurgis	1	0	0	0	0	1
willis	1	1	0	0	0	0
wbkry	1	0	0	0	1	0
wiedergiebt	1	0	0	0	0	1
wächtersepulcrum	1	0	0	0	0	1
winfride	1	0	0	0	0	1
wilgisus	2	0	0	0	0	2
wilhelmi	1	0	0	0	0	1
wulfrici	1	0	0	0	0	1
we–re–se–e	2	0	0	0	2	0
wortes	1	1	0	0	0	0
wholly	1	0	0	0	1	0
wind	1	0	0	0	1	0
woher	1	1	0	0	0	0
wilielmo	1	0	0	0	0	1
wurzeburc	1	0	0	0	0	1
wo–i–wa–ni–ya–se	1	0	0	0	1	0
wag	1	0	0	0	0	1
wurd	1	0	0	0	0	1
wormatiensibus	1	0	0	0	0	1
werdo	4	0	0	0	0	4
watheim	1	0	0	0	0	1
wattenheim	1	0	0	0	0	1
wirina	1	0	0	0	0	1
wirk	1	1	0	0	0	0
woring	1	0	0	0	0	1
worringen	1	0	0	0	0	1
wlbnyhwn	1	0	0	0	0	1
wlbn	1	0	0	0	0	1
wujûd–humâ	1	0	0	0	0	1
worteego	1	0	0	0	0	1
weiterer	3	0	0	0	3	0
walpodo	3	0	0	0	0	3
wa–na–ka–sa–ko–ra–se	1	0	0	0	1	0
wort	1	0	0	0	0	1
wlznsu	1	1	0	0	0	0
willelma	2	0	0	0	0	2
wolfgang	2	0	0	0	0	2
willerus	2	0	0	0	0	2
wiueraht	1	0	0	0	0	1
wowimus	1	0	0	0	0	1
wariento	1	0	0	0	0	1
warmundi	1	0	0	0	0	1
weinmelchisedec	1	0	0	0	0	1
wenceslai	2	0	0	0	0	2
we|zilo	1	0	0	0	0	1
witizani	1	0	0	0	0	1
wi–	1	0	0	0	1	0
wadouulfo	1	0	0	1	0	0
wirunt	2	0	0	0	0	2
wiberti	1	0	0	0	0	1
winzeburc	2	0	0	0	0	2
warmundus	1	0	0	0	0	1
welcher	1	0	0	0	0	1
waelkens	1	0	0	0	1	0
wlabenius	1	0	0	0	0	1
writing	2	0	0	0	2	0
wassersüchtigen	1	0	0	0	0	1
widerici	1	0	0	0	0	1
willeman	1	0	0	0	0	1
wezel	1	0	0	0	0	1
wormaciensis	2	0	0	0	0	2
wiltrudis	2	0	0	0	0	2
wabuetusus	1	0	0	0	0	1
w-	1	0	0	0	0	1
weinberg	1	0	0	0	1	0
walterius	1	0	0	0	0	1
wtms	1	0	0	0	0	1
wirceburgensis	1	0	0	0	0	1
wattenhein	1	0	0	0	0	1
wicelino	1	0	0	0	0	1
witernensi	1	0	0	0	0	1
wirtnwerg	1	0	0	0	0	1
wowemus	1	0	0	0	0	1
wirundi	2	0	0	0	0	2
wenkebachpfaff	1	1	0	0	0	0
willemsen	1	0	0	0	1	0
wa–ri–mi–yo–ne	2	0	0	0	2	0
wigfride	1	0	0	0	0	1
wolfiani	1	1	0	0	0	0
walli	1	0	0	0	0	1
wescher	1	1	0	0	0	0
wlfmaeg	1	0	0	0	0	1
wlfrici	1	0	0	0	0	1
witgario	1	0	0	0	0	1
widegouo	1	0	0	0	0	1
weiltingen	1	0	0	0	0	1
winterschozze	1	0	0	0	0	1
witica	1	0	0	0	0	1
wytles	1	0	0	0	0	1
wick–snuffers	1	0	0	0	0	1
wrote	1	0	0	0	0	1
woentra	1	0	0	0	0	1
wignandus	2	0	0	0	0	2
wolken	2	0	0	0	0	2
wolcenik	1	0	0	0	0	1
we–ka–te–ti–po–si–ro–ti	1	0	0	0	1	0
willibirg	1	0	0	0	0	1
wo–ro–i–ko	1	0	0	0	1	0
wiboradae	1	0	0	0	0	1
westliches	1	0	0	0	0	1
walde	1	0	0	0	0	1
wilke	1	1	0	0	0	0
willigisi	1	0	0	0	0	1
womari	1	0	0	0	0	1
weit	1	1	0	0	0	0
wyrican	1	0	0	0	0	1
widone	2	0	0	0	0	2
werdonis	1	0	0	0	0	1
wilhelms	1	0	0	0	1	0
willem	1	0	0	0	0	1
wart	1	0	0	0	0	1
wolgeborne	1	0	0	0	0	1
wileyci	1	0	0	0	0	1
würzburg	1	0	0	0	1	0
wadamirus	1	0	0	0	0	1
welles	1	0	0	0	1	0
wigberto	1	0	0	0	0	1
wὁ	1	0	0	0	1	0
wb	1	1	0	0	0	0
we–po	1	0	0	0	1	0
we–i–se–se	1	0	0	0	1	0
wiborada	2	0	0	0	0	2
wahrscheinlich	1	1	0	0	0	0
wimerskirch	1	0	0	0	0	1
wirtzburgum	1	0	0	0	0	1
wiederadam	1	0	0	0	0	1
wilhe|lmus	1	0	0	0	0	1
wolfg	1	1	0	0	0	0
we–ke	1	0	0	0	1	0
wezelin	1	0	0	0	0	1
wolfhart	1	0	0	0	0	1
witardus	1	0	0	0	0	1
weggebröckelt	1	0	0	0	1	0
womarus	1	0	0	0	0	1
wichmannus	1	0	0	0	0	1
wace	1	0	0	0	1	0
wernheri	1	0	0	0	0	1
wamba	2	0	0	0	0	2
widh	1	0	0	0	0	1
wallis	1	1	0	0	0	0
walpertii	1	0	0	0	0	1
wo–le	1	0	0	0	1	0
wo–sἱ	1	0	0	0	1	0
wolfii	1	1	0	0	0	0
wne	1	0	0	0	0	1
wοάϲονι	1	0	0	0	1	0
walathini	1	0	0	0	0	1
wess	1	1	0	0	0	0
wahdi–hi	1	0	0	0	0	1
wxxa	1	1	0	0	0	0
wamarg	1	1	0	0	0	0
wadha–hu	1	0	0	0	0	1
wespanus	1	0	0	0	0	1
wistremius	1	0	0	0	0	1
wo–i–	1	0	0	0	1	0
\.


--
-- TOC entry 16898 (class 1259 OID 197098)
-- Name: wcindex_w; Type: INDEX; Schema: public; Owner: hippa_wr
--

CREATE UNIQUE INDEX wcindex_w ON public.wordcounts_w USING btree (entry_name);


--
-- TOC entry 17026 (class 0 OID 0)
-- Dependencies: 3376
-- Name: TABLE wordcounts_w; Type: ACL; Schema: public; Owner: hippa_wr
--

GRANT SELECT ON TABLE public.wordcounts_w TO hippa_rd;


-- Completed on 2019-10-09 15:22:40 UTC

--
-- PostgreSQL database dump complete
--

