--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2 (Ubuntu 13.2-1)
-- Dumped by pg_dump version 13.2 (Ubuntu 13.2-1)

-- Started on 2021-05-17 21:30:10 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 3716 (class 1259 OID 241054)
-- Name: wordcounts_y; Type: TABLE; Schema: public; Owner: hippa_wr
--

CREATE TABLE public.wordcounts_y (
    entry_name character varying(64),
    total_count integer DEFAULT 0,
    gr_count integer DEFAULT 0,
    lt_count integer DEFAULT 0,
    dp_count integer DEFAULT 0,
    in_count integer DEFAULT 0,
    ch_count integer DEFAULT 0
);


ALTER TABLE public.wordcounts_y OWNER TO hippa_wr;

--
-- TOC entry 17080 (class 0 OID 241054)
-- Dependencies: 3716
-- Data for Name: wordcounts_y; Type: TABLE DATA; Schema: public; Owner: hippa_wr
--

COPY public.wordcounts_y (entry_name, total_count, gr_count, lt_count, dp_count, in_count, ch_count) FROM stdin;
yl	214	214	0	0	0	0
y	746	689	26	1	4	26
ypodecta	2	0	0	2	0	0
ythalonimualoniuthsicorathiisthymhimihymacomsyth	1	0	1	0	0	0
yayb	133	133	0	0	0	0
ys/rl	15	0	0	0	0	15
ya	46	46	0	0	0	0
yrena	2	0	0	0	0	2
yb	16	16	0	0	0	0
yyayb	9	9	0	0	0	0
ymnis	5	0	0	0	0	5
yth	5	0	5	0	0	0
ys	11	9	2	0	0	0
ypsichius	1	0	0	0	0	1
yhzql	3	0	0	0	0	3
ymetto	1	0	1	0	0	0
ymettos	1	0	1	0	0	0
yppolitus	5	0	0	0	0	5
ypoblattae	1	0	0	0	0	1
yhy	4	0	0	0	0	4
yn	3	0	0	0	0	3
yi	16	16	0	0	0	0
yls	25	25	0	0	0	0
yk	23	23	0	0	0	0
yshq	3	0	0	0	0	3
yup	32	32	0	0	0	0
yr	8	6	0	0	0	2
yupr	1	1	0	0	0	0
yridem	3	2	0	1	0	0
ytalie	1	0	0	0	0	1
ymberti	1	0	0	0	0	1
young	2	0	0	0	1	1
ydropicus	3	0	0	0	0	3
yqb	2	0	0	0	0	2
ygt	13	13	0	0	0	0
yid	1	0	1	0	0	0
youth	1	0	0	0	1	0
ybξa	4	4	0	0	0	0
yitam	1	0	0	0	0	1
ymmo	8	0	0	0	0	8
ymnos	1	0	0	0	0	1
yz	5	0	0	5	0	0
yyzzuu	2	0	0	0	0	2
ys☩ys	2	0	0	0	0	2
ynstans	1	0	0	0	0	1
ypoquistide	1	0	1	0	0	0
yon	1	0	1	0	0	0
ymago	6	0	0	0	0	6
ydrops	1	0	1	0	0	0
ypatio	4	0	0	0	0	4
ytn	3	0	0	0	3	0
yesu	1	0	0	0	0	1
ymnus	4	0	0	0	0	4
ypobolen	1	0	1	0	0	0
ysaias	7	0	0	0	0	7
ysaacius	3	0	0	0	1	2
ypallagen	1	0	1	0	0	0
ywšh	2	0	0	0	0	2
yalensia	3	3	0	0	0	0
yfm	1	1	0	0	0	0
yryn	1	0	0	0	0	1
yqsw	1	0	0	0	0	1
ycine	1	0	0	0	0	1
ypoteta	1	0	1	0	0	0
ypacares	2	0	2	0	0	0
yconomicorum	1	1	0	0	0	0
yâ	1	0	0	0	0	1
yaladhdha	1	0	0	0	0	1
ydus	15	0	0	0	0	15
youtie	2	2	0	0	0	0
yıldız"	1	0	0	0	1	0
ypoliti	4	0	0	0	0	4
yt	1	0	0	0	0	1
yris	1	1	0	0	0	0
yguia	2	0	0	0	0	2
yrmindrudis	1	0	0	0	0	1
yrws/lym	2	0	0	0	0	2
ylu	1	0	0	0	0	1
ygumenus	1	0	0	0	0	1
you	2	0	0	0	1	1
ymaginum	3	0	0	0	0	3
yedra	1	0	0	0	0	1
ysacha	1	0	0	0	0	1
ypoquistidos	7	0	7	0	0	0
ypoquistida	1	0	1	0	0	0
ydreuma	1	0	0	1	0	0
year	2	0	0	0	2	0
youths	2	0	0	0	1	1
yik	2	2	0	0	0	0
yhzqyh	1	0	0	0	0	1
yšrwn	1	0	0	0	0	1
ymagines	2	0	0	0	0	2
ysaiam	2	0	0	0	0	2
yya	10	10	0	0	0	0
yterii	2	0	0	0	0	2
yc	1	0	0	0	0	1
ya–sa–wi–ri–sa–ne	1	0	0	0	1	0
ydria	4	0	1	0	0	3
yperbolen	1	0	1	0	0	0
ynwh	4	0	0	0	0	4
yαυ	2	0	0	0	2	0
ypogeu	1	0	0	0	0	1
yaenae	1	0	1	0	0	0
ynmis	2	0	0	0	0	2
ymaginem	1	0	0	0	0	1
ysaac	3	0	0	0	0	3
yaybξa	2	2	0	0	0	0
yesus	1	0	0	0	0	1
yrimfridus	1	0	0	0	0	1
ysymbertus	1	0	0	0	0	1
yax	1	1	0	0	0	0
ywsyy	1	0	0	0	0	1
yuz	3	0	0	2	0	1
ypocondriis	1	0	1	0	0	0
yhwdh	2	0	0	0	0	2
ypotecarii	1	0	0	0	0	1
ymnidi	1	0	0	0	1	0
yrbia	1	0	0	1	0	0
ydrie	1	0	0	0	0	1
ylario	1	0	0	0	0	1
ypsicrates	1	0	1	0	0	0
ysayas	2	0	0	0	0	2
yhwsp	3	0	0	0	0	3
ypoticae	1	0	0	1	0	0
yx	1	0	0	0	0	1
ywνίου	1	0	0	1	0	0
ynyh	1	0	0	0	0	1
yppoliti	4	0	0	1	0	3
yaday	2	0	0	0	0	2
ybrk	3	0	0	0	3	0
yuxή	1	1	0	0	0	0
ygendorp	1	0	0	0	0	1
yαρᾶϲ	2	0	0	0	2	0
ycit	1	0	0	0	0	1
yreus	2	0	2	0	0	0
yaξa	1	1	0	0	0	0
yahpc	1	1	0	0	0	0
ysenburc	2	0	0	0	0	2
yorke	1	0	0	0	1	0
yhsp	2	0	0	0	0	2
yqwb	2	0	0	0	0	2
ynnynu	1	0	1	0	0	0
yslym	1	0	1	0	0	0
yyb	2	2	0	0	0	0
yacinthi	1	0	0	0	0	1
yš|rwn	1	0	0	0	0	1
ypsiuremeta	1	0	0	0	0	1
yestinus	1	0	0	0	0	1
ywsp	1	0	0	0	0	1
yfrg	1	0	0	0	1	0
y|dola	1	0	0	0	0	1
yrinis	1	0	0	0	0	1
ya–ra–se	2	0	0	0	2	0
ythmum	1	0	1	0	0	0
ysthyalm	1	0	1	0	0	0
ych–ibarcu	1	0	1	0	0	0
yf	2	2	0	0	0	0
ydropis	1	0	0	0	0	1
ydropicum	2	0	0	0	0	2
yppolite	1	0	0	0	0	1
ypologo	1	0	0	1	0	0
ysenach	1	0	0	0	0	1
ylup	5	5	0	0	0	0
ydrea	1	0	1	0	0	0
ydibus	1	0	0	0	0	1
ymberto	1	0	0	0	0	1
ya–e	1	0	0	0	1	0
ycxq	1	0	0	0	1	0
ysimbertus	1	0	0	0	0	1
ymaginum⌋	2	0	0	0	0	2
yiiii	1	0	0	0	0	1
ylus	1	0	0	0	0	1
yperechiam	1	0	0	0	0	1
ydriam	1	0	1	0	0	0
ymma	1	0	0	0	0	1
yacinthus	1	0	0	0	0	1
yacinthe	1	0	0	0	0	1
yincente	1	0	0	1	0	0
yaqûlu	1	0	0	0	0	1
ymo	1	0	0	0	0	1
yixsit	1	0	0	0	0	1
ysmidone	1	0	0	0	0	1
ypoquistidam	1	0	1	0	0	0
ypolitus	2	0	0	0	0	2
yixit	2	0	0	0	0	2
yiii	2	0	0	0	0	2
yyaybξa	1	1	0	0	0	0
ydolorum	1	0	0	0	0	1
ya–u	1	0	0	0	1	0
yacentus	1	0	0	0	0	1
ypermestram	1	0	1	0	0	0
ybelin	1	0	0	0	0	1
ysiodoro	1	0	0	0	0	1
yrmgardis	1	0	0	0	0	1
ysabellis	2	0	0	0	0	2
yscription∙	1	0	0	1	0	0
yashadu	1	0	0	0	0	1
yma	1	0	0	0	0	1
ypograpsas	1	1	0	0	0	0
yrene	1	0	0	0	0	1
yukup	1	1	0	0	0	0
yisaac	1	0	0	0	0	1
yecessa	1	0	0	0	0	1
ynnocho	1	0	1	0	0	0
yspano	1	0	0	0	0	1
yale	1	1	0	0	0	0
yαρᾷ	1	0	0	0	1	0
yspania	1	0	0	0	0	1
yxy	1	0	0	0	0	1
yycc	1	0	0	0	0	1
ymbertus	1	0	0	0	0	1
yp	1	0	0	0	0	1
yong	1	0	0	0	0	1
yups	2	2	0	0	0	0
yuo	1	0	0	0	0	1
ysagrio	1	0	0	0	0	1
ytto	1	0	0	1	0	0
ypocistidos	1	0	1	0	0	0
yesse	1	0	0	0	0	1
ylpius	1	0	0	1	0	0
yûlad	1	0	0	0	0	1
yakun	1	0	0	0	0	1
ymis	1	0	0	0	0	1
yairus	1	0	0	0	0	1
ymaginis	1	0	0	0	0	1
ywdn	1	0	0	0	0	1
yez"	1	0	0	1	0	0
yconomica	1	1	0	0	0	0
yppolito	1	0	0	0	0	1
yxa	1	1	0	0	0	0
\.


--
-- TOC entry 16949 (class 1259 OID 241063)
-- Name: wcindex_y; Type: INDEX; Schema: public; Owner: hippa_wr
--

CREATE UNIQUE INDEX wcindex_y ON public.wordcounts_y USING btree (entry_name);


--
-- TOC entry 17086 (class 0 OID 0)
-- Dependencies: 3716
-- Name: TABLE wordcounts_y; Type: ACL; Schema: public; Owner: hippa_wr
--

GRANT SELECT ON TABLE public.wordcounts_y TO hippa_rd;


-- Completed on 2021-05-17 21:30:10 UTC

--
-- PostgreSQL database dump complete
--

