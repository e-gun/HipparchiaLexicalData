--
-- PostgreSQL database dump
--

-- Dumped from database version 14.7 (Ubuntu 14.7-0ubuntu0.22.10.1)
-- Dumped by pg_dump version 14.7 (Ubuntu 14.7-0ubuntu0.22.10.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: wordcounts_y; Type: TABLE; Schema: public; Owner: hippa_wr
--

CREATE TABLE public.wordcounts_y (
    entry_name character varying(64),
    total_count integer DEFAULT 0,
    gr_count integer DEFAULT 0,
    lt_count integer DEFAULT 0,
    dp_count integer DEFAULT 0,
    in_count integer DEFAULT 0,
    ch_count integer DEFAULT 0
);


ALTER TABLE public.wordcounts_y OWNER TO hippa_wr;

--
-- Data for Name: wordcounts_y; Type: TABLE DATA; Schema: public; Owner: hippa_wr
--

COPY public.wordcounts_y (entry_name, total_count, gr_count, lt_count, dp_count, in_count, ch_count) FROM stdin;
yayb	133	133	0	0	0	0
yxy	1	0	0	0	0	1
yl	214	214	0	0	0	0
y	746	689	26	1	4	26
yup	32	32	0	0	0	0
yguia	2	0	0	0	0	2
yesse	1	0	0	0	0	1
ymaginis	1	0	0	0	0	1
yk	23	23	0	0	0	0
ysaias	7	0	0	0	0	7
ys/rl	15	0	0	0	0	15
ytn	3	0	0	0	3	0
yαρᾶϲ	2	0	0	0	2	0
ysenburc	2	0	0	0	0	2
ypogeu	1	0	0	0	0	1
ymnus	4	0	0	0	0	4
yi	16	16	0	0	0	0
ypatio	4	0	0	0	0	4
ya	46	46	0	0	0	0
ynwh	4	0	0	0	0	4
yb	16	16	0	0	0	0
ypermestram	1	0	1	0	0	0
ygt	13	13	0	0	0	0
ymberto	1	0	0	0	0	1
yid	1	0	1	0	0	0
ylup	5	5	0	0	0	0
yhy	4	0	0	0	0	4
yyayb	9	9	0	0	0	0
ysaiam	2	0	0	0	0	2
ymbertus	1	0	0	0	0	1
yls	25	25	0	0	0	0
yecessa	1	0	0	0	0	1
ydus	15	0	0	0	0	15
ymaginum	3	0	0	0	0	3
ycine	1	0	0	0	0	1
ymo	1	0	0	0	0	1
yixit	2	0	0	0	0	2
ymnos	1	0	0	0	0	1
ymagines	2	0	0	0	0	2
ylu	1	0	0	0	0	1
yuz	3	0	0	2	0	1
yrimfridus	1	0	0	0	0	1
yedra	1	0	0	0	0	1
ys	11	9	2	0	0	0
yth	5	0	5	0	0	0
ymnis	5	0	0	0	0	5
yhsp	2	0	0	0	0	2
ydropicum	2	0	0	0	0	2
yscription∙	1	0	0	1	0	0
yreus	2	0	2	0	0	0
ypoquistide	1	0	1	0	0	0
yhzql	3	0	0	0	0	3
yppolitus	5	0	0	0	0	5
yterii	2	0	0	0	0	2
yαυ	2	0	0	0	2	0
yon	1	0	1	0	0	0
yisaac	1	0	0	0	0	1
yrmindrudis	1	0	0	0	0	1
ypotecarii	1	0	0	0	0	1
ynyh	1	0	0	0	0	1
yyaybξa	1	1	0	0	0	0
ypsichius	1	0	0	0	0	1
ylpius	1	0	0	1	0	0
yqwb	2	0	0	0	0	2
yûlad	1	0	0	0	0	1
yakun	1	0	0	0	0	1
yc	1	0	0	0	0	1
ytto	1	0	0	1	0	0
yhwdh	2	0	0	0	0	2
ythmum	1	0	1	0	0	0
ysthyalm	1	0	1	0	0	0
ych–ibarcu	1	0	1	0	0	0
yrmgardis	1	0	0	0	0	1
ydria	4	0	1	0	0	3
yya	10	10	0	0	0	0
yt	1	0	0	0	0	1
ynstans	1	0	0	0	0	1
ylario	1	0	0	0	0	1
yconomica	1	1	0	0	0	0
yryn	1	0	0	0	0	1
ydibus	1	0	0	0	0	1
ymmo	8	0	0	0	0	8
ypsiuremeta	1	0	0	0	0	1
ydolorum	1	0	0	0	0	1
yr	8	6	0	0	0	2
ywšh	2	0	0	0	0	2
yincente	1	0	0	1	0	0
yrinis	1	0	0	0	0	1
yridem	3	2	0	1	0	0
yp	1	0	0	0	0	1
yuo	1	0	0	0	0	1
young	2	0	0	0	1	1
ysayas	2	0	0	0	0	2
yn	3	0	0	0	0	3
yqsw	1	0	0	0	0	1
ymis	1	0	0	0	0	1
you	2	0	0	0	1	1
yaξa	1	1	0	0	0	0
ymago	6	0	0	0	0	6
ynmis	2	0	0	0	0	2
yorke	1	0	0	0	1	0
yppoliti	4	0	0	1	0	3
yyzzuu	2	0	0	0	0	2
ys☩ys	2	0	0	0	0	2
yik	2	2	0	0	0	0
yiiii	1	0	0	0	0	1
ybξa	4	4	0	0	0	0
yz	5	0	0	5	0	0
yalensia	3	3	0	0	0	0
ypodecta	2	0	0	2	0	0
ydrie	1	0	0	0	0	1
ymaginum⌋	2	0	0	0	0	2
yfrg	1	0	0	0	1	0
yšrwn	1	0	0	0	0	1
ybelin	1	0	0	0	0	1
yaday	2	0	0	0	0	2
ysagrio	1	0	0	0	0	1
yycc	1	0	0	0	0	1
ylus	1	0	0	0	0	1
ymaginem	1	0	0	0	0	1
ymnidi	1	0	0	0	1	0
yashadu	1	0	0	0	0	1
ypoblattae	1	0	0	0	0	1
yupr	1	1	0	0	0	0
ysacha	1	0	0	0	0	1
yshq	3	0	0	0	0	3
yups	2	2	0	0	0	0
yestinus	1	0	0	0	0	1
yspania	1	0	0	0	0	1
ynnocho	1	0	1	0	0	0
yâ	1	0	0	0	0	1
yaladhdha	1	0	0	0	0	1
ypsicrates	1	0	1	0	0	0
ypallagen	1	0	1	0	0	0
ydrea	1	0	1	0	0	0
yukup	1	1	0	0	0	0
yhwsp	3	0	0	0	0	3
ypoquistidam	1	0	1	0	0	0
yaqûlu	1	0	0	0	0	1
ypoliti	4	0	0	0	0	4
ywsp	1	0	0	0	0	1
youtie	2	2	0	0	0	0
yixsit	1	0	0	0	0	1
ypoquistidos	7	0	7	0	0	0
ysimbertus	1	0	0	0	0	1
year	2	0	0	0	2	0
ypograpsas	1	1	0	0	0	0
yαρᾷ	1	0	0	0	1	0
ypacares	2	0	2	0	0	0
ysaac	3	0	0	0	0	3
youths	2	0	0	0	1	1
yf	2	2	0	0	0	0
yrws/lym	2	0	0	0	0	2
ypobolen	1	0	1	0	0	0
youth	1	0	0	0	1	0
ysmidone	1	0	0	0	0	1
yrena	2	0	0	0	0	2
ypocistidos	1	0	1	0	0	0
yqb	2	0	0	0	0	2
ypolitus	2	0	0	0	0	2
ysabellis	2	0	0	0	0	2
ya–sa–wi–ri–sa–ne	1	0	0	0	1	0
ya–ra–se	2	0	0	0	2	0
yma	1	0	0	0	0	1
yong	1	0	0	0	0	1
ycxq	1	0	0	0	1	0
yyb	2	2	0	0	0	0
yacinthe	1	0	0	0	0	1
yesu	1	0	0	0	0	1
yrbia	1	0	0	1	0	0
yacentus	1	0	0	0	0	1
yperechiam	1	0	0	0	0	1
yrene	1	0	0	0	0	1
yaybξa	2	2	0	0	0	0
yahpc	1	1	0	0	0	0
ydropicus	3	0	0	0	0	3
ydreuma	1	0	0	1	0	0
ypoticae	1	0	0	1	0	0
yris	1	1	0	0	0	0
yppolite	1	0	0	0	0	1
yppolito	1	0	0	0	0	1
ywνίου	1	0	0	1	0	0
ybrk	3	0	0	0	3	0
yiii	2	0	0	0	0	2
yacinthus	1	0	0	0	0	1
yhzqyh	1	0	0	0	0	1
ysaacius	3	0	0	0	1	2
yspano	1	0	0	0	0	1
yuxή	1	1	0	0	0	0
yfm	1	1	0	0	0	0
yesus	1	0	0	0	0	1
yairus	1	0	0	0	0	1
yaenae	1	0	1	0	0	0
y|dola	1	0	0	0	0	1
yacinthi	1	0	0	0	0	1
ynnynu	1	0	1	0	0	0
yslym	1	0	1	0	0	0
yx	1	0	0	0	0	1
yxa	1	1	0	0	0	0
ythalonimualoniuthsicorathiisthymhimihymacomsyth	1	0	1	0	0	0
ygumenus	1	0	0	0	0	1
ymberti	1	0	0	0	0	1
ydropis	1	0	0	0	0	1
ypocondriis	1	0	1	0	0	0
ymetto	1	0	1	0	0	0
ymettos	1	0	1	0	0	0
ypoteta	1	0	1	0	0	0
yš|rwn	1	0	0	0	0	1
ypoquistida	1	0	1	0	0	0
yale	1	1	0	0	0	0
ywdn	1	0	0	0	0	1
ygendorp	1	0	0	0	0	1
yax	1	1	0	0	0	0
ymma	1	0	0	0	0	1
ycit	1	0	0	0	0	1
ysiodoro	1	0	0	0	0	1
yitam	1	0	0	0	0	1
ya–e	1	0	0	0	1	0
yıldız"	1	0	0	0	1	0
ydriam	1	0	1	0	0	0
ywsyy	1	0	0	0	0	1
ydrops	1	0	1	0	0	0
yconomicorum	1	1	0	0	0	0
yperbolen	1	0	1	0	0	0
ytalie	1	0	0	0	0	1
yez"	1	0	0	1	0	0
ysymbertus	1	0	0	0	0	1
ya–u	1	0	0	0	1	0
ysenach	1	0	0	0	0	1
ypologo	1	0	0	1	0	0
\.


--
-- Name: wcindex_y; Type: INDEX; Schema: public; Owner: hippa_wr
--

CREATE UNIQUE INDEX wcindex_y ON public.wordcounts_y USING btree (entry_name);


--
-- PostgreSQL database dump complete
--

