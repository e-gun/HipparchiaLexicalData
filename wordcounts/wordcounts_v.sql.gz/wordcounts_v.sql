--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2 (Ubuntu 13.2-1)
-- Dumped by pg_dump version 13.2 (Ubuntu 13.2-1)

-- Started on 2021-05-17 21:30:08 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 3713 (class 1259 OID 241024)
-- Name: wordcounts_v; Type: TABLE; Schema: public; Owner: hippa_wr
--

CREATE TABLE public.wordcounts_v (
    entry_name character varying(64),
    total_count integer DEFAULT 0,
    gr_count integer DEFAULT 0,
    lt_count integer DEFAULT 0,
    dp_count integer DEFAULT 0,
    in_count integer DEFAULT 0,
    ch_count integer DEFAULT 0
);


ALTER TABLE public.wordcounts_v OWNER TO hippa_wr;

--
-- TOC entry 17080 (class 0 OID 241024)
-- Dependencies: 3713
-- Data for Name: wordcounts_v; Type: TABLE DATA; Schema: public; Owner: hippa_wr
--

COPY public.wordcounts_v (entry_name, total_count, gr_count, lt_count, dp_count, in_count, ch_count) FROM stdin;
\.


--
-- TOC entry 16949 (class 1259 OID 241033)
-- Name: wcindex_v; Type: INDEX; Schema: public; Owner: hippa_wr
--

CREATE UNIQUE INDEX wcindex_v ON public.wordcounts_v USING btree (entry_name);


--
-- TOC entry 17086 (class 0 OID 0)
-- Dependencies: 3713
-- Name: TABLE wordcounts_v; Type: ACL; Schema: public; Owner: hippa_wr
--

GRANT SELECT ON TABLE public.wordcounts_v TO hippa_rd;


-- Completed on 2021-05-17 21:30:09 UTC

--
-- PostgreSQL database dump complete
--

